public class ArgsDemo {
    public static void main(String[] args) {
        System.out.println("Argument 1 " +args[0]);
        System.out.println("Argument 2 " +args[1]);
    }
}