public class Student {
    int sno;
    String name;
    String city;
    double cgp;

    @Override
    public String toString() {
        return "Student No  " +sno+ " Student Name " +name+ " City  " +city+ " Cgp  " +cgp;
    }
}