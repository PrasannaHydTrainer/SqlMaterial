public class ConEmploy {

    public static void main(String[] args) {
        Employ emp1 = new Employ();
        System.out.println(emp1);
    }

}