public class Demo1 {

    public static void main(String[] args) {
        Employ emp1 = new Employ();
        emp1.empno=1;
        emp1.name="Suresh";
        emp1.basic=88423;

        System.out.println(emp1);
    }
}