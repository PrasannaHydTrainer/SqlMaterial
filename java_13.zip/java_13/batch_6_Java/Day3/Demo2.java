public class Demo2 {
    public static void main(String[] args) {
        Student s1 = new Student();
        s1.sno=1;
        s1.name="Syed";
        s1.city="Bangalore";
        s1.cgp=8.8;

        System.out.println(s1);
    }
}