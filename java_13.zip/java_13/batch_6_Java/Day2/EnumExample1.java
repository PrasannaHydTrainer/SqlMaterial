enum DayName {
    SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY,FRIDAY, SATURDAY
}

public class EnumExample1 {

    public static void main(String[] args) {
        DayName obj = DayName.THURSDAY;
        System.out.println(obj);
    }
}