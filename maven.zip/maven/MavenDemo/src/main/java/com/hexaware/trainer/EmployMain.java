package com.hexaware.trainer;

public class EmployMain {
    public static void main(String[] args) {
        Employ employ1 = new Employ();
        employ1.setEmpno(1);
        employ1.setName("Prasad");
        employ1.setBasic(84823.43);

        System.out.println(employ1);
    }
}