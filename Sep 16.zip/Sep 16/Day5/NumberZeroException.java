public class NumberZeroException extends Exception {
    NumberZeroException(String error) {
        super(error);
    }
}