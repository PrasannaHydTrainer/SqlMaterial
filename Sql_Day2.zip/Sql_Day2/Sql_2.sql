select job, sal from Emp;

select job, sum(sal) from Emp 
group by job;