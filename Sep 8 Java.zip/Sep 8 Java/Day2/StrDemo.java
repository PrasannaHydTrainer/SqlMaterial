public class StrDemo {
    public static void main(String[] args) {
        String s1="Anuja", s2="Syed", s3="Prasad", s4="Anuja";
        System.out.println(s1.hashCode());
        System.out.println(s2.hashCode());
        System.out.println(s3.hashCode());
        System.out.println(s4.hashCode());
    }
}