select gender from Agent;

-- DISTINCT : Used to eliminate duplicate entries at the time of display. 

select distinct Gender from Agent;

