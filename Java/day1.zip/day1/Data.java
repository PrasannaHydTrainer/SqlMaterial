public class Data {

    public static void main(String[] args) {
        Demo obj = new Demo();
        obj.anuja();
        obj.suresh();
    //    obj.bhavani();
    }
}