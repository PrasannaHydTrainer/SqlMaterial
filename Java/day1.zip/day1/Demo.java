public class Demo {

    public void anuja() {
        System.out.println("Hi I am Anuja...");
    }

    void suresh() {
        System.out.println("Hi I am Suresh Reddy...");
    }

    private void bhavani() {
        System.out.println("Hi I am Bhavani...");
    }
}