-- Display all records whose Mgr is null 

select * from Emp where mgr is null;

-- Display all records whose comm is NULL

select * from Emp where comm is NULL;

