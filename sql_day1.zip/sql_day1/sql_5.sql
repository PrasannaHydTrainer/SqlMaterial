-- Number Functions 

-- Abs() : Returns the absolute value 

select abs(-12);

-- power(n,m) : return n power m value 

select power(2,3);

-- sqrt(n) : Returns the sqrt value 

select sqrt(49);

-- Ceiling() : returns the greatest integer value 

select ceiling(12.000000000000001); 

-- floor() : Returns the smallest integer value 

select floor(12.99999999999999);